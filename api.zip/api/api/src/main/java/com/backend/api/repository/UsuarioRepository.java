package com.backend.api.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.backend.api.model.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Serializable>{

	public List<Usuario> findAll();
	
	public Usuario findById(Long id);
	
	public void deleteById(Long id);
	
	@SuppressWarnings("unchecked")
	public Usuario save(Usuario usuario);
	
}
