package com.backend.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.backend.api.model.Usuario;
import com.backend.api.repository.UsuarioRepository;

@Service
public class UsuarioService {
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Transactional(readOnly = true)
	public List<Usuario> findAll(){
		return this.usuarioRepository.findAll();
	}
	
	@Transactional(readOnly = true)
	public Usuario findById(Long id) {
		return this.usuarioRepository.findById(id);
	}
	
	@Transactional
	public void deleteById(Long id) {
		this.usuarioRepository.deleteById(id);
	}
	
	@Transactional
	public Usuario save(Usuario usuario) {
		return this.usuarioRepository.save(usuario);
	}
}
