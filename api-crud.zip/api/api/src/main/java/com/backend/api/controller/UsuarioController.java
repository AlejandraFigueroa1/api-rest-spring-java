package com.backend.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.backend.api.model.Usuario;
import com.backend.api.service.UsuarioService;



@CrossOrigin()
@RestController
@RequestMapping("/api/v1")
public class UsuarioController {
	@Autowired 
	private UsuarioService usuarioService;
	
	
	@GetMapping("/usuarios")
	public ResponseEntity<?> getAllUsuarios(){
		List<Usuario> usuarios = this.usuarioService.findAll();
		Map<String, Object> response = new HashMap<>();
		response.put("data", usuarios);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	
	@GetMapping("/usuarios/{id}")
	public ResponseEntity<?> getUsuarioById(@PathVariable("id") Long id){
		Usuario usuario = this.usuarioService.findById(id);
		Map<String, Object> response = new HashMap<>();
		response.put("data", usuario);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@PostMapping("/usuarios")
	public ResponseEntity<?> saveUsuario(@RequestBody Usuario usuario){
		Usuario newUsuario = this.usuarioService.save(usuario);
		//return ResponseEntity<?> this.usuarioService.save(usuario);
		Map<String, Object> response = new HashMap<>();
		response.put("data", newUsuario);
		return new ResponseEntity<>(response, HttpStatus.OK);
		
	}
	
	@DeleteMapping ("/usuarios/{id}")
	public ResponseEntity<?> deleteUsuario(@PathVariable("id") Long id) {
		this.usuarioService.deleteById(id);
		Map<String, Object> response = new HashMap<>();
		response.put("data", null);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@PutMapping("/usuarios/{id}")
	public ResponseEntity<?> updateUsuario(@PathVariable ("id") Long id, @RequestBody Usuario usuario){
		Usuario usuarioActual = this.usuarioService.findById(id);
		
		if(usuarioActual == null) {
			return null;
		}
		
		usuarioActual.setCorreo(usuario.getCorreo());
		usuarioActual.setEdad(usuario.getEdad());
		usuarioActual.setNombreCompleto(usuario.getNombreCompleto());
		usuarioActual.setTelefono(usuario.getTelefono());
		Usuario usuarioActualizado = this.usuarioService.save(usuarioActual);
		
		Map<String, Object> response = new HashMap<>();
		response.put("data", usuarioActualizado);
		return new ResponseEntity<>(response, HttpStatus.OK);	
		
	}
	
	
}
